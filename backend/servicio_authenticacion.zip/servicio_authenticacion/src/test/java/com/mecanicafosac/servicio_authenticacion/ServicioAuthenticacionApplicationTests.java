package com.mecanicafosac.servicio_authenticacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioAuthenticacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
