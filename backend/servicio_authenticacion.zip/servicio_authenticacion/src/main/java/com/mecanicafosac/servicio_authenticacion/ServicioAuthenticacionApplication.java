package com.mecanicafosac.servicio_authenticacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioAuthenticacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioAuthenticacionApplication.class, args);
	}

}
